/**
 联系方式: forjs.org  QQ 1405491181  微信公众号 forjs_org
 视频版权所有: 曾亮 <1405491181@qq.com>
 淘宝店出售、云盘下载和个人私下出售本课程的，均为盗版。未经许可，不可对此视频翻录和用于商业用途，违者必究。
 购买到盗版的学员，可与作者联系,有奖励+赠送一套课程。
 【会员】可免费学习曾老师发布的所有课程，和会员有效期内讲师新发布的所有课程。可咨询QQ 1405491181
 */


const Redux = require("redux");

const store = Redux.createStore(function reducer(state, action) {
    if (typeof state === "undefined") return {};
    switch (action.type) {
        case "changeName":
            return Object.assign({}, state, { name: action.name });
        default:
            return {};
    }
});


// ---------------------  one
// const action = {
//     type: "changeName",
//     name: 'leo'
// };


// store.dispatch(action);

// const action2 = {
//     type: "changeName",
//     name: 'liangzeng'
// }


// ------------------- two
// function actionCreator(name) {
//     return {
//         name,
//         type: "changeName"
//     }
// }


// store.dispatch(actionCreator("leo"));
// store.dispatch(actionCreator("liangzeng"));

// ------------------- three

// function createAction(action, dispatch) {
//     return function (opt) {
//         action = Object.assign({}, action, opt, { type: action.type });
//         dispatch(action);
//     }
// }


// var action = createAction({ type: "changeName", name: "leo" }, store.dispatch);

// action();
// action({name:"zengliang"});


// --------------------- four

// function createActions(actions, dispatch) {

//     function createAction(action, dispatch) {
//         return function (opt) {
//             action = Object.assign({}, action, opt, { type: action.type });
//             dispatch(action);
//         }
//     }

//     if (typeof actions === 'function') {
//         return createAction(actions, dispatch);
//     } else {
//         let result = {};
//         for (var k in actions) {
//             result[k] = createAction(actions[k], dispatch);
//         }
//         return result;
//     }

// }


// let a = { type: "a" };
// let b = { type: "b" };
// let c = { type: "c" };


// let actions = createActions({ a, b, c }, store.dispatch);

// actions.a();
// actions.b();


// ---------------------  finish

function a(name,id) {
    return {
        type: "a",
        name,
        id
    }
}


function b(name) {
    return {
        type: "b",
        name
    }
}


let actions = Redux.bindActionCreators({a,b},store.dispatch);


actions.a("leo",'id001');
