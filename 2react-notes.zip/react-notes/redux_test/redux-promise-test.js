/**
 联系方式: ourjs.cn  QQ 1405491181  微信公众号 forjs_org
 视频版权所有: 曾亮 <1405491181@qq.com>
 淘宝店出售、云盘下载和个人私下出售本课程的，均为盗版。未经许可，不可对此视频翻录和用于商业用途，违者必究。
 购买到盗版的学员，可与作者联系,有奖励。
 【会员】可免费学习曾老师已发布的，和会员期内新发布的所有课程；已买过单课的，办理会卡有一定的优惠。咨询QQ 1405491181
 */
"use strict";
const redux = require("redux");
const promise = require("redux-promise");

// import thunk from "redux-thunk";

// let createStore = redux.applyMiddleware(thunk)(redux.createStore);

function reducer(state, action) {
    if (typeof state === "undefined") return {};
    switch (action.type) {
        case "changeName": return { name: action.payload.name };
        default: return state;
    }
}

const store = redux.createStore(reducer, redux.applyMiddleware(promise));


function action(name) {
    return { payload:{name}, type: "changeName" }
}

let asyncAction = function (name) {

    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // dispatch(action("action1"));
            resolve(action(name));
        }, 1000);
    });

}

store.subscribe(() => {
    console.log(store.getState());
})

store.dispatch(asyncAction("zengliang"));

