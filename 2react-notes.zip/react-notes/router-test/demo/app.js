
/**
 联系方式: ourjs.cn  QQ 1405491181  微信公众号 forjs_org
 视频版权所有: 曾亮 <1405491181@qq.com>
 淘宝店出售、云盘下载和个人私下出售本课程的，均为盗版。未经许可，不可对此视频翻录和用于商业用途，违者必究。
 购买到盗版的学员，可与作者联系,有奖励。
 【会员】可免费学习曾老师已发布的，和会员期内新发布的所有课程；已买过单课的，办理2年会员卡有一定的优惠。咨询QQ 1405491181
 */

import {Router, Route, Link} from "react-router";
import React from "react";
import {render} from "react-dom";


const App = React.createClass({
    render() {
        return <div>

            <Link to="/aaa">A</Link> <span> | </span>

            <Link to="/bbb">B</Link> <span> | </span>

            <Link to="/ccc">C</Link>

            <ul>
                <li><Link to="/bbb/b1"> B1 </Link></li>
                <li><Link to="/bbb/b2"> B2 </Link></li>
            </ul>

            <hr/>

            <div>{this.props.children}</div>

        </div>
    }
});

const A = React.createClass({
    render() {
        return <h4> AAAA </h4>
    }
});


const B = React.createClass({
    render() {
        return <ul>
            <li>
                {this.props.children}
            </li>
        </ul>
    }
})

const B1 = React.createClass({
    render() {
        return <h4> B1 B1  </h4>
    }
})

const B2 = React.createClass({
    render() {
        return <h4> B2 b2  </h4>
    }
})

const C = React.createClass({
    render() {
        return <h4> CCCC </h4>
    }
})


render(
    <Router>
        <Route path="/" component={App}>
            <Route path="aaa" component={A} />
            <Route path="bbb" component={B} >
                <Route path="b1" component={B1} />
                <Route path="b2" component={B2} />
            </Route>
            <Route path="ccc" component={C} />
        </Route>
    </Router>
    , document.body)


