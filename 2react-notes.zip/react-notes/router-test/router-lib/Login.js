
import React from "react";
import _Navbar  from "./Navbar";
import {createStore} from "redux";
import { connect , Provider } from "react-redux";
import UserList from "./UserList";


export default React.createClass({

    render(){

       return <div> Login </div>
    }
})